#include "naobehavior.h"
#include "../rvdraw/rvdraw.h"

extern int agentBodyType;

/*
 * Real game beaming.
 * Filling params x y angle
 */
void NaoBehavior::beam(double &beamX, double &beamY, double &beamAngle)
{
    if (worldModel->getUNum() == 1)
    {
        beamX = 0;
        beamY = 0;
        beamAngle = 0;
    }
    if (worldModel->getUNum() == 2)
    {
        beamX = -4;
        beamY = 2;
        beamAngle = 0;
    }
    if (worldModel->getUNum() == 3)
    {
        beamX = -4;
        beamY = -2;
        beamAngle = 0;
    }
    if (worldModel->getUNum() == 4)
    {
        beamX = -6;
        beamY = -4;
        beamAngle = 0;
    }
    if (worldModel->getUNum() == 5)
    {
        beamX = -6;
        beamY = 4;
        beamAngle = 0;
    }
}

SkillType NaoBehavior::selectSkill()
{

    // My position and angle
    //cout << worldModel->getUNum() << ": " << worldModel->getMyPosition() << ",\t" << worldModel->getMyAngDeg() << "\n";

    // Position of the ball
    //cout << worldModel->getBall() << "\n";

    // Example usage of the roboviz drawing system and RVSender in rvdraw.cc.
    // Agents draw the position of where they think the ball is
    // Also see example in naobahevior.cc for drawing agent position and
    // orientation.
    /*
    worldModel->getRVSender()->clear(); // erases drawings from previous cycle
    worldModel->getRVSender()->drawPoint("ball", ball.getX(), ball.getY(), 10.0f, RVSender::MAGENTA);
    */

    // ### Demo Behaviors ###

    // Walk in different directions
    //return goToTargetRelative(VecPosition(1,0,0), 0); // Forward
    //return goToTargetRelative(VecPosition(-1,0,0), 0); // Backward
    //return goToTargetRelative(VecPosition(0,1,0), 0); // Left
    //return goToTargetRelative(VecPosition(0,-1,0), 0); // Right
    //return goToTargetRelative(VecPosition(1,1,0), 0); // Diagonal
    //return goToTargetRelative(VecPosition(0,1,0), 90); // Turn counter-clockwise
    //return goToTargetRelative(VecPdosition(0,-1,0), -90); // Turn clockwise
    //return goToTargetRelative(VecPosition(1,0,0), 15); // Circle

    // Walk to the ball
    //return goToTarget(ball);

    // Turn in place to face ball
    /*double distance, angle;
    getTargetDistanceAndAngle(ball, distance, angle);
    if (abs(angle) > 10) {
      return goToTargetRelative(VecPosition(), angle);
    } else {
      return SKILL_STAND;
    }*/

    // Walk to ball while always facing forward
    //return goToTargetRelative(worldModel->g2l(ball), -worldModel->getMyAngDeg());

    // Dribble ball toward opponent's goal
    //return kickBall(KICK_DRIBBLE, VecPosition(HALF_FIELD_X, 0, 0));

    // Kick ball toward opponent's goal
    //return kickBall(KICK_FORWARD, VecPosition(HALF_FIELD_X, 0, 0)); // Basic kick
    //return kickBall(KICK_IK, VecPosition(HALF_FIELD_X, 0, 0)); // IK kick

    // Just stand in place
    //return SKILL_STAND;

    // Demo behavior where players form a rotating circle and kick the ball
    // back and forth
    return demoKickingCircle();
}

/*
 * Demo behavior where players form a rotating circle and kick the ball
 * back and forth
 */
SkillType NaoBehavior::demoKickingCircle()
{
    worldModel->ChangePlayMode();
    if (worldModel->getUNum() == 1 || worldModel->getUNum() == 2 || worldModel->getUNum() == 3 || worldModel->getUNum() == 4 || worldModel->getUNum() == 5)
    {
        if (worldModel->getPlayMode() == PM_KICK_OFF_LEFT)
            return goToTarget(VecPosition(10, 10, 0));
        if (worldModel->getPlayMode() == PM_KICK_OFF_RIGHT)
            return goToTarget(VecPosition(10, -10, 0));
    }
}
